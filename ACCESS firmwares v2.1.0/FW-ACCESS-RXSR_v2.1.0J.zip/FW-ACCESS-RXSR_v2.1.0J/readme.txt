
*******************************Release Note******************************************

This Package is for Receivers ACCESS v2.1.0 firmware update for RXSR. 

Version and Files: 
RXSR_ACCESS_191107.frsk                               Upgrade file for RXSR
RXSR_ACCESS_RSSI16_2.1.0J.frsk                   Upgrade file for RXSR,channel 16 of SBUS signal will be used for RSSI output.
readme.txt                                                               Release note 
 
Firmware Version: v2.1.0

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
  1. Fixed the channel output error (uncontrolled servo movements) under certain conditions.
  2. Improved RF performance, improved connection reliability & stability, and increased range.
  3. Improve the stability of telemetry feedback.
  4. Add FLR(Frame Lost Rate) display.
  5. Add configurable function of telemetry power.
  6. S.port and F.port canbe chosed in receiver options menu in radio.

Note: Please update the firmware of all your radios(latest openTx or FrOS), RF modules and receivers accordingly.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/
https://www.frsky-rc.com/product/r-xsr/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 