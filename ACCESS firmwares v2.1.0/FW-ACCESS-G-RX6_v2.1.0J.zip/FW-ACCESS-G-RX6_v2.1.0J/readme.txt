
*******************************Release Note******************************************

This Package is for G-RX8 ACCESS v2.1.0 firmware update. J is a beta test version number.

Version and Files: 

G-RX6_ACCESS_2.1.0.frsk                                 Upgrade file for G-RX6
readme.txt                                              Release note 
 
Firmware Version: v2.1.0

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
  1. Fixed the channel output error (uncontrolled servo movements) under certain conditions.
  2. Improved RF performance, improved connection reliability & stability, and increased range.
  3. Improve the stability of telemetry feedback.
  4. Add FLR(Frame Lost Rate) display.
  5. Add configurable function of telemetry power.

Note: Please update the firmware of all your radios(latest openTx or FrOS), RF modules and receivers accordingly.
-------------------------------------------------------------------------------------------------------------------
How to update receiver firmware :
https://www.frsky-rc.com/how-to-use-the-transmitter-to-flash-the-firmware-of-the-x8r-receiver/

-------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/
https://www.frsky-rc.com/product/g-rx6/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 