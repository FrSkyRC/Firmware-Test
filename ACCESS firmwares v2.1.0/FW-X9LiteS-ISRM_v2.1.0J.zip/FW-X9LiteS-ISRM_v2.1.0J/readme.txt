
*******************************Release Note******************************************

This Package is for ISRM-S module v2.1.0 firmware update. 

Version and Files: 
ISRM-S-X9LiteS_2.1.0.frsk                            Upgrade file for internal module of X9Lite S.


readme.txt                                                         Release note 
 
Firmware Version: v2.1.0

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
ACCESS:

    Fixed the channel output error (uncontrolled servo movements) under certain conditions.
    Improved RF performance, improved connection reliability & stability, and increased range.
    Improve the stability of telemetry feedback.
    Add FLR(Frame Lost Rate) display.
    Add configurable function of telemetry power.

ACCST:

    Fixed the channel output error (uncontrolled servo movements) under certain conditions.
    Strengthened correction and verification capability.

Note: Please update the firmware of all your radios(latest openTx or FrOS), RF modules and receivers accordingly.
-------------------------------------------------------------------------------------------------------------------
How to update internal module ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/
https://www.frsky-rc.com/product/taranis-x9-lite-s/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 